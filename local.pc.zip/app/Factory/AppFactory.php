<?php

declare(strict_types=1);

namespace App\Factory;

use App\Support\ShutdownHandler;
use DI\Bridge\Slim\Bridge;
use Psr\Log\LoggerInterface;
use Slim\Factory\ServerRequestCreatorFactory;
use Slim\Handlers\ErrorHandler;

final class AppFactory extends BaseFactory
{
    /**
     * @return \Slim\App
     */
    public static function create(): mixed
    {
        ContainerFactory::addDefinitions(BASEDIR . '/app/definitions.php');
        $container = ContainerFactory::create();
        $app = Bridge::create($container);

        (require_once BASEDIR . '/app/middlewares.php')($app);
        (require_once BASEDIR . '/app/routes.php')($app);

        (!DEBUG) && $app->getRouteCollector()->setCacheFile(__DIR__ . '/../var/cache/routes.php');

        $callableResolver = $app->getCallableResolver();
        $responseFactory = $app->getResponseFactory();
        $errorHandler = new ErrorHandler(
            $callableResolver,
            $responseFactory,
            $container->get(LoggerInterface::class),
        );

        $request = ServerRequestCreatorFactory::create()
            ->createServerRequestFromGlobals();

        $shutdownHandler = new ShutdownHandler($request, $errorHandler, DEBUG);
        register_shutdown_function($shutdownHandler);

        $app->addErrorMiddleware(DEBUG, true, DEBUG)
            ->setDefaultErrorHandler($errorHandler);

        return $app;
    }
}
