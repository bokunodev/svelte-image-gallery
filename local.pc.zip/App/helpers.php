<?php

namespace App;

use Exception;

if (function_exists('throw_if')) {
    function throw_if(bool $cond, string $msg, int $code, string $exception_class = Exception::class): void
    {
        if ($cond) {
            throw new $exception_class($msg, $code);
        }
    }
}
