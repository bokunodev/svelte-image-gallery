<?php

use App\Factory\AppFactory;

require_once '../vendor/autoload.php';

defined('BASEDIR') || define('BASEDIR', dirname(__DIR__));

AppFactory::create()->run();
