<?php

namespace App\Factory;

use DI\ContainerBuilder;

final class ContainerFactory extends BaseFactory
{
    private static array $definitions = [];

    public static function addDefinitions(array|string $definitions)
    {
        $definitions = is_string($definitions) ? (require_once $definitions) : $definitions;
        self::$definitions[] = $definitions;
    }

    /**
     * @return \DI\Container
     */
    public static function create(): mixed
    {
        $containerBuilder = new ContainerBuilder();
        $containerBuilder->addDefinitions(...self::$definitions);

        if (!DEBUG) {
            $containerBuilder->enableCompilation(BASEDIR . '/var/cache');
        }

        return $containerBuilder->build();
    }
}
