<?php

namespace App;

use function DI\string;
use Monolog\Handler\HandlerInterface as ILogHandler;
use Monolog\Handler\StreamHandler;
use Monolog\Logger;
use Monolog\Processor\PsrLogMessageProcessor;
use Monolog\Processor\WebProcessor;
use Psr\Container\ContainerInterface as IContainer;
use Psr\Log\LoggerInterface as ILogger;

return [
    IContainer::class => fn (IContainer $c) => $c,
    ILogger::class => function (IContainer $c, ILogHandler $handler) {
        $logger = new Logger($c->get('app.name'));

        return $logger
            ->pushProcessor(new WebProcessor())
            ->pushProcessor(new PsrLogMessageProcessor())
            ->pushHandler($handler);
    },

    ILogHandler::class => function (IContainer $c) {
        return new StreamHandler($c->get('log.path'), $c->get('log.level'), true, $c->get('log.permision'));
    },

    'app.name' => 'local.pc',
    'log.path' => string(BASEDIR . '/var/logs/{app.name}.log'),
    'log.level' => fn () => DEBUG ? Logger::DEBUG : Logger::WARNING,
    'log.permision' => 0664,
];
