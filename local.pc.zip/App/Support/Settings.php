<?php

namespace App\Support;

final class Settings
{
    public const writable_dir = BASEDIR . '/var';
    public const cache_dir = self::writable_dir . '/cache';
    public const log_dir = self::writable_dir . '/log';
    public const resources_dir = BASEDIR . '/resources';
    public const public_dir = BASEDIR . '/public';
    public const twig_root_path = self::resources_dir;
    public const twig_paths = [
        self::resources_dir,
    ];

    public const twig_options = [
        'debug' => true,
        'cache' => false,
        'charset' => 'UTF-8',
        'autoescape' => 'html',
        'auto_reload' => null,
        'optimizations' => -1,
        'strict_variables' => true,
    ];
}
