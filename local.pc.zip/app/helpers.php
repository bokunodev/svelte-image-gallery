<?php

namespace App;

use Exception;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Throwable;

if (!function_exists('App\throw_if')) {
    function throw_if(bool $cond, string $msg, int $code = 0, Throwable $prev = null, string $exceptionClass = Exception::class)
    {
        $cond && throw new $exceptionClass($msg, $code, $prev);
    }
}

if (!function_exists('App\respond_file')) {
    function respond_file(string $path, Request $request, Response $response, ?string $mime = null, ?string $disposition = null, int $chunk = 1 << 20): Response
    {
        $mime = $mime ?: mime_content_type($path);
        $mime = $mime ?: 'octetapplication/octet-stream';
        $response = $response->withHeader('Content-Type', $mime);

        if ($disposition) {
            $response = $response->withHeader('Content-Disposition', $disposition);
        }

        if ('HEAD' === $request->getMethod()) {
            return $response;
        }

        $fileSize = (int) filesize($path);
        if (!$request->hasHeader('Range')) {
            $response = $response->withHeader('Content-Length', $fileSize);
            $body = $response->getBody();
            $file = fopen($path, 'r');
            while ($content = fread($file, $chunk)) {
                $body->write($content);
            }
            fclose($file);

            return $response;
        }

        $matches = [];
        preg_match('/^bytes=(\d+)-(\d+)?/', $request->getHeaderLine('Range'), $matches, PREG_UNMATCHED_AS_NULL);
        $start = (int) $matches[1];
        $end = (int) $matches[2] ?: $fileSize;
        $range = $end - $start;
        $quotient = $range % $chunk;
        $count = ceil($range / $chunk);
        $reminder = $end - ($quotient * $count);

        $response = $response->withHeader('Content-Length', $range);
        $body = $response->getBody();
        $file = fopen($path, 'r');
        fseek($file, $start, SEEK_SET);
        for ($i = 0; $i < $count; $i++) {
            $content = fread($file, $quotient);
            if (!$content) {
                break;
            }
            $body->write($content);
        }

        if ($reminder > 0) {
            $content = fread($file, $reminder);
            $body->write($content);
        }
        ob_flush();

        fclose($file);

        return $response;
    }
}
