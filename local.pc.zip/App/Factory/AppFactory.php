<?php

namespace App\Factory;

use App\Support\ShutdownHandler;
use DI\Bridge\Slim\Bridge;
use DI\ContainerBuilder;
use Slim\App;
use Slim\Handlers\ErrorHandler;
use Slim\Psr7\Factory\ServerRequestFactory;

class AppFactory
{
    public static function create(): App
    {
        $isProduction = 'production' === getenv('ENVIRONMENT');

        $containerBuilder = new ContainerBuilder();
        $containerBuilder->addDefinitions(BASEDIR . '/App/container.php');

        if ($isProduction) {
            $containerBuilder->enableCompilation(BASEDIR . '/var/cache');
            $containerBuilder->writeProxiesToFile(true, BASEDIR . '/var/cache');
        }

        $container = $containerBuilder->build();

        $app = Bridge::create($container);

        $errorHandler = new ErrorHandler(
            $app->getCallableResolver(),
            $app->getResponseFactory(),
        );

        $shutdownHandler = new ShutdownHandler(
            ServerRequestFactory::createFromGlobals(),
            $errorHandler,
            !$isProduction,
        );

        register_shutdown_function($shutdownHandler);

        $app->addErrorMiddleware(!$isProduction, true, true)
            ->setDefaultErrorHandler($errorHandler);

        (require_once BASEDIR . '/App/routes.php')($app);

        if ($isProduction) {
            $app->getRouteCollector()
                ->setCacheFile(BASEDIR . '/var/cache/routes.php');
        }

        return $app;
    }
}
