<?php

use Slim\Routing\RouteCollectorProxy;
use Src\Login\Action\LoginFormAction;

return function (RouteCollectorProxy $route) {
    $route->get('/login', LoginFormAction::class);
};
