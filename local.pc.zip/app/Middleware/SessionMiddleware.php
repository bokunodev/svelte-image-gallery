<?php

namespace App\Middleware;

use function App\throw_if;
use Psr\Container\ContainerInterface;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;

class SessionMiddleware implements MiddlewareInterface
{
    public function __construct(ContainerInterface $c)
    {
        ini_set('session.save_path', BASEDIR . '/var/session');
        ini_set('session.save_handler', 'files');
        ini_set('session.auto_start', 1);
        ini_set('session.cookie_lifetime', 7200);
        ini_set('session.cookie_path', '/');
        ini_set('session.cookie_domain', $_SERVER['SERVER_NAME']);
        ini_set('session.cookie_secure', 0);
        ini_set('session.cookie_httponly', 1);
        ini_set('session.cookie_samesite', 1);
        ini_set('session.use_strict_mode', 1);
        ini_set('session.use_cookies', 1);
        ini_set('session.use_only_cookies', 1);
        ini_set('session.referer_check', 1);
        ini_set('session.cache_limiter', 'private');
        ini_set('session.cache_expire', 180);
    }

    public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface
    {
        throw_if(!session_start(), 'Error: failed to start session');

        return $handler->handle($request);
    }
}
