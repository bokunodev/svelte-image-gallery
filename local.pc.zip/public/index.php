<?php

declare(strict_types=1);

use App\Factory\AppFactory;

require_once __DIR__ . '/../vendor/autoload.php';

define('DEBUG', 'production' !== getenv('ENVIRONMENT'));
define('BASEDIR', dirname(__DIR__));

/**
 * @var \Slim\App $app
 */
$app = AppFactory::create();

$app->run();
