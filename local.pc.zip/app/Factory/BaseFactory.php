<?php

namespace App\Factory;

abstract class BaseFactory
{
    abstract public static function create(): mixed;
}
