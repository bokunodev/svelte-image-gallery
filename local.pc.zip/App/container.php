<?php

use App\Support\Settings;
use function DI\create;
use Psr\Container\ContainerInterface;
use Psr\Http\Message\ResponseFactoryInterface;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestFactoryInterface;
use Psr\Http\Message\ServerRequestInterface;
use Slim\Psr7\Factory\ResponseFactory;
use Slim\Psr7\Factory\ServerRequestFactory;
use Twig\Environment;
use Twig\Loader\FilesystemLoader;

return [
    ResponseFactoryInterface::class => create(ResponseFactory::class),
    ServerRequestFactoryInterface::class => create(ServerRequestFactory::class),
    ServerRequestInterface::class => fn (ContainerInterface $c) => $c->get(ServerRequestFactoryInterface::class)->createFromGlobals(),
    ResponseInterface::class => fn (ContainerInterface $c) => $c->get(ResponseFactoryInterface::class)->createResponse(),

    Environment::class => function () {
        return new Environment(
            new FilesystemLoader(Settings::twig_paths, Settings::twig_root_path),
            Settings::twig_options,
        );
    },
];
