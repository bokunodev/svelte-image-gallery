<?php

namespace App;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Slim\Routing\RouteCollectorProxy as Router;

return function (Router $route) {
    $route->get('[/{file:.*}]', function (Request $request, Response $response, string $file): Response {
        $response = $response->withHeader('Cache-Control', 'nocache');
        if (empty($_SESSION['userdata']) && 'login' !== trim($file, '/')) {
            return $response->withHeader('Location', '/login')->withStatus(307);
        }

        return respond_file(BASEDIR . "/public/{$file}", $request, $response);
    });
};
