<?php

namespace Src\Login\Action;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Twig\Environment;

class LoginFormAction
{
    private Environment $twig;

    public function __construct(Environment $twig)
    {
        $this->twig = $twig;
    }

    public function __invoke(Request $req, Response $res): Response
    {
        $payload = $this->twig->render('pages/login.twig.html');
        $res->getBody()->write($payload);

        return $res;
    }
}
